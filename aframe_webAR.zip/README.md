# aframe_webAR
Aframe webAR demo with trex image marker
